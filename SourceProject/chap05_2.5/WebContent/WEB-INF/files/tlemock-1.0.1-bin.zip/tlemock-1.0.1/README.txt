Installing Tlemock
==================

The following instructions show how to install Tlemock 1.0:

1) Unpack the archive where you would like to store the binaries, eg:
  unzip tlemock-1.0.1-bin.zip

2) A directory called "tlemock-1.0.1" will be created.

3) Append tlemock-1.0.1.jar to CLASSPATH.

4) Append lib/cglib-nodep-2.1_3.jar to CLASSPATH.

For more information, please see http://www.tleproject.net/tlemock/

