Welcome to Apache ActiveMQ 
========================== 
Apache ActiveMQ is a high performance Apache 2.0 licenced Message Broker and JMS 1.1 implementation.


Getting Started
===============
To help you get started, try the following links:-

Getting Started
http://activemq.apache.org/getting-started.html

Building
http://activemq.apache.org/getting-started.html#GettingStarted-WindowsSourceInstallation
http://activemq.apache.org/getting-started.html#GettingStarted-UnixSourceInstallation

Examples
http://activemq.apache.org/examples.html

We welcome contributions of all kinds, for details of how you can help
http://activemq.apache.org/contributing.html

Please refer to the website for details of finding the issue tracker, email lists, wiki or IRC channel
http://activemq.apache.org/

Please help us make Apache ActiveMQ better - we appreciate any feedback you may have.
Enjoy!

------------------------
The Apache ActiveMQ team
